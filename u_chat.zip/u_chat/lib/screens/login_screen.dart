import 'package:flutter/cupertino.dart';
import 'package:u_chat/screens/chat_screen.dart';
import 'package:flutter/material.dart';
import 'package:u_chat/components/rounded_button.dart';
import 'package:u_chat/constants.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginScreen extends StatefulWidget {
  static const String id = 'login_screen';
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController username = new TextEditingController();
  TextEditingController password = new TextEditingController();

  bool checkValue = false;

  SharedPreferences sharedPreferences;

  @override
  void initState() {
    super.initState();
    getCredential();
  }
  String email,passwords;
  final _auth = FirebaseAuth.instance;
  bool showSpinner = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ModalProgressHUD(
        inAsyncCall: showSpinner,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Flexible(
                child: Hero(
                  tag: 'logo',
                  child: Container(
                    height: 200.0,
                    child: Image.asset('images/anchor-point.ico'),
                  ),
                ),
              ),
              SizedBox(
                height: 48.0,
              ),
              TextField(
                controller: username,
                textAlign: TextAlign.center,
                keyboardType: TextInputType.emailAddress,
                onChanged: (value) {
                  email = (value);
                },
                decoration:
                    kTextFieldDecoration.copyWith(hintText: 'Enter your Email'),
              ),
              SizedBox(
                height: 8.0,
              ),
              TextField(
                controller: password,
                textAlign: TextAlign.center,
                obscureText: true,
                onChanged: (value) {
                  passwords = (value);
                },
                decoration: kTextFieldDecoration.copyWith(
                    hintText: 'Enter your password'),
              ),
              new CheckboxListTile(
                value: checkValue,
                onChanged: _onChanged,
                title: new Text("Remember me"),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              SizedBox(
                height: 24.0,
              ),
              RoundedButton(
                title: 'login',
                colour: Colors.blueAccent,
                onpressed: () async {
                  setState(() {
                    showSpinner = true;
                  }); onTap: _navigator;
                  try {
                    final newUser = await _auth.signInWithEmailAndPassword(
                        email: email, password: passwords);
                    if (newUser != null) {
                      Navigator.pushNamed(context, ChatScreen.id);
                    }
                    setState(() {
                      showSpinner = false;
                    });
                  } catch (e) {
                    print(e);kErrorMsgAlert(context).show();
                  }finally {
                    setState(() {
                      showSpinner = false;
                    });
                  }
                },
              ),
              new Container(
                decoration:
                new BoxDecoration(border: Border.all(color: Colors.black)),
                child: new ListTile(
                  title: new Text(
                    "Login",
                    textAlign: TextAlign.center,
                  ),
                  onTap: _navigator,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

_onChanged(bool value) async {
  sharedPreferences = await SharedPreferences.getInstance();
  setState(() {
    checkValue = value;
    sharedPreferences.setBool("check", checkValue);
    sharedPreferences.setString("username", username.text);
    sharedPreferences.setString("password", password.text);
    sharedPreferences.commit();
    getCredential();
  });
}

getCredential() async {
  sharedPreferences = await SharedPreferences.getInstance();
  setState(() {
    checkValue = sharedPreferences.getBool("check");
    if (checkValue != null) {
      if (checkValue) {
        username.text = sharedPreferences.getString("username");
        password.text = sharedPreferences.getString("password");
      } else {
        username.clear();
        password.clear();
        sharedPreferences.clear();
      }
    } else {
      checkValue = false;
    }
  });
}

_navigator() {
  if (username.text.length != 0 || password.text.length != 0) {
    Navigator.of(context).pushAndRemoveUntil(
        new MaterialPageRoute(
            builder: (BuildContext context) => new ChatScreen()),
            (Route<dynamic> route) => false);
  } else {
    showDialog(
        context: context,
        barrierDismissible: false,
        child: CupertinoAlertDialog(
          content: Text(
            "username or password \ncan't be empty",
            style: new TextStyle(fontSize: 16.0),
          ),
          actions: <Widget>[
            new FlatButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: new Text("OK"))
          ],
        ));
  }
}
}
